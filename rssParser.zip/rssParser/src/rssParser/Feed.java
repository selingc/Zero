package rssParser;

//Missing: BRYAN ARANDA (CA)
//BRYAN ARANDA, Age Now: 14, Missing: 03/02/2017. Missing From HUNTINGTON PARK, CA. ANYONE HAVING INFORMATION SHOULD CONTACT: Huntington Park Police Department (California)  1-323-584-6254.
public class Feed {

	String title;
	String link;
	String description;
	String location;
	String date;
	
	public Feed(String title, String link, String description){
		
		this.title = title;
		this.link = link;
		this.description = description;
		setLocation(description);
		setDate(description);
	}
	
	public void setLocation(String description){
		int a = description.indexOf("Missing From ");
		int b = description.indexOf(".", description.indexOf(".")+2);
		location = description.substring(a + "Missing From ".length(), b);
	}
	
	public void setDate(String description){
		int a = description.indexOf("Missing: ");
		int b = description.indexOf(".", a+2);
		date = description.substring(a + "Missing: ".length(), b);
	}
	
	
	public String toString(){
		return title + "\n"+ "\n" + description +"\n" + location +" "+date+"\n";
	}
}


