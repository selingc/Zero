package rssParser;

public class Parsertest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String line = "BRYAN ARANDA, Age Now: 14, Missing: 03/02/2017. Missing From HUNTINGTON PARK, CA. ANYONE HAVING INFORMATION SHOULD CONTACT: Huntington Park Police Department (California)  1-323-584-6254.";
		int i = line.indexOf("Missing From ");
		//System.out.println(i);
		//System.out.println(line.substring(i + "Missing From ".length()));
		
		int a = line.indexOf(".", line.indexOf(".")+2);
	//	System.out.println(a);
//		System.out.println(line.substring(a));
		System.out.println(line.substring(i + "Missing From ".length(), a));
	}

}
