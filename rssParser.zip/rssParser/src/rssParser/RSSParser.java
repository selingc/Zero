package rssParser;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

import org.json.JSONObject;

import org.apache.commons.digester.Digester;
import org.apache.commons.digester.rss.Channel;
import org.apache.commons.digester.rss.Item;
import org.apache.commons.digester.rss.RSSDigester;

public class RSSParser {

	public static void main(String[] args) throws Exception {
			int MAX = 200;
		    
			//initialize and set up disgestere
	        RSSDigester digester=new RSSDigester();
	        String feed = "http://www.missingkids.org/missingkids/servlet/XmlServlet?act=rss&LanguageCountry=en_US&orgPrefix=NCMC&state=CA";
	        URL url=new URL(feed);
	        HttpURLConnection httpSource=
	            (HttpURLConnection)url.openConnection();
	        Channel channel=
	            (Channel)digester.parse(httpSource.getInputStream());
	        if (channel==null) {
	            throw new Exception("can't communicate with " + url);
	        }
	        
	        //get item array
	        Item rssItems[]=channel.findItems();
	        //json object array
	        JSONObject[] arr = new JSONObject[MAX];
	        
	        System.out.println("Length: "+rssItems.length);
	       
	        //loop through and create feedobject
	        for (int i=0;i<MAX;i++) {
	           Item item = rssItems[i];
	           Feed objectFeed = new Feed(item.getTitle(), item.getLink(), item.getDescription());
	           
	           JSONObject value = new JSONObject();
	           value.put("title", objectFeed.title);
	           value.put("link", objectFeed.link);
	           value.put("description", objectFeed.description);
	           value.put("location", objectFeed.location);
	           value.put("date", objectFeed.date);
	           arr[i] = value;	           
	        }
	        
	        try{
				File file = new File("feed.json");
				FileWriter writer = new FileWriter(file.getAbsoluteFile());
				BufferedWriter buffer = new BufferedWriter(writer);
				buffer.write("[");
				for(int i = 0; i < MAX; i++){
					if(i == MAX-1)
						buffer.write(arr[i].toString());
					else
						buffer.write(arr[i].toString()+",");
					buffer.write("\n");
					
				}
				buffer.write("]");
				buffer.close();
				
			}catch(IOException ex){
				System.out.println("File not found");
			}
	    }
	

	

}
